#Lista de Exercícios

##1 Descrever um Algoritmo para resolver o problema da travessia de modo "seguro':



###Um homem precisa atravessar um rio com um barco que possui capacidade apenas para carregar ele mesmo e mais um de seus três pertences, que são: um lobo, uma cabra e um maço de alfafa. Em cada viagem só poderá ir o homem e apenas um de seus pertences. A seguinte regra deverá ser respeitada: o lobo não pode ficar sozinho com a cabra e nem a cabra sozinha com o maço de alfafa. Escreva um algoritmo para fazer a travessia dos pertences que estão em uma margem do rio para a outra.



Ida 1: levar a cabra para o outro lado

Volta 1: trazer o barco vazio

Ida 2: levar o lobo para o outro lado

Volta 2: trazer a cabra de volta

Ida 3: levar o maço de alfafa para o outro lado

Volta 3: trazer o barco vazio

Ida 4: levar a cabra para o outro lado





##2 JS: Exibir média de 3 números com entradas pelo formulário HTML Enviar link(s) do git ou do fiddle
link do CodePen: A Pen by Débora Videira Monteiro (codepen.io)